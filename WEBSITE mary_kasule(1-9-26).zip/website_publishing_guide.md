# How to Publish Your Portfolio Websites and Add New Projects
## Complete Guide for Mary's Career Portfolio

---

## Your Two Websites

### Website 1: Career Journey Website
**Location**: https://claude.ai/chat/3322ea76-0b1d-43fa-8dc5-f2be1bd08267
**Purpose**: Personal career transformation story, journal, budgeting, life planning

### Website 2: Healthcare Analytics Portfolio
**Location**: https://claude.ai/chat/b6553632-8b4a-4cff-873b-45fe72702c18
**Purpose**: Professional portfolio showcasing data analytics projects (Bellabeat, EV Market, Cardiac Rehab)

---

## OPTION A: Quick & Free - Publish on GitHub Pages (Recommended)

### What You Need
- GitHub account (free)
- 15 minutes of setup time
- No coding required beyond copy/paste

### Step-by-Step Instructions

#### Step 1: Create GitHub Account (if you don't have one)
1. Go to https://github.com
2. Click "Sign up"
3. Use your email: choose a professional username like `mary-healthcare-analytics` or `mary-datascience`
4. Verify your email

#### Step 2: Create Repository for Your Portfolio
1. Click the **"+" icon** in top right → **"New repository"**
2. **Repository name**: `portfolio` (or `mary-portfolio`)
3. **Description**: "Healthcare Data Analytics Portfolio - Mary [Your Last Name]"
4. Select **"Public"**
5. Check **"Add a README file"**
6. Click **"Create repository"**

#### Step 3: Get Your Website Code from Claude
1. **Go back to your Healthcare Analytics Portfolio chat**: https://claude.ai/chat/b6553632-8b4a-4cff-873b-45fe72702c18
2. Scroll to the artifact (the interactive website preview on the right side)
3. Click the **three dots** (⋯) in the top right corner of the artifact
4. Click **"Copy code"** - this copies the entire website code

#### Step 4: Upload to GitHub
1. In your GitHub repository, click **"Add file"** → **"Create new file"**
2. Name the file: `index.html`
3. Paste the code you copied from Claude
4. Scroll to bottom, click **"Commit new file"**

#### Step 5: Enable GitHub Pages (Make It Live!)
1. In your repository, click **"Settings"** tab
2. Scroll down to **"Pages"** in left sidebar (under "Code and automation")
3. Under **"Source"**, select **"Deploy from a branch"**
4. Under **"Branch"**, select **"main"** and folder **"/ (root)"**
5. Click **"Save"**
6. **Wait 2-3 minutes** - GitHub will build your site
7. Refresh the page - you'll see: **"Your site is live at https://your-username.github.io/portfolio/"**

🎉 **Your website is now LIVE on the internet!**

---

## Adding Your Weekend Schedule Optimization Project

### Method 1: Ask Claude to Update the Website (Easiest)

1. Go to THIS chat (where we just created your project)
2. Copy this message and send it:

```
Claude, I need to add the Weekend Schedule Optimization project to my Healthcare Analytics Portfolio website. 

Here's what I need:
1. Open my portfolio website from this chat: https://claude.ai/chat/b6553632-8b4a-4cff-873b-45fe72702c18
2. Add a new project card to the "Projects" section with these details:

**Project Title**: Weekend Schedule Optimization & Workload Analysis
**Category**: Healthcare Operations Analytics
**Description**: Analyzed staff scheduling and task allocation for residential care setting supporting 6 individuals with developmental/intellectual disabilities. Identified 25% workload variance and designed role-based optimization model reducing variance to <10% while improving care consistency.

**Tools Used**: Google Sheets, SQL, Statistical Analysis, Process Optimization
**Key Outcomes**:
- Reduced staff workload variance from 25% to <10%
- Improved care consistency for highest-needs individuals by 67%
- Eliminated 8-10 scheduling conflicts per weekend
- Created measurable KPIs for ongoing optimization

**Metrics**: 
- Individuals: 6
- Staff: 4
- Variance Reduction: 60%

3. Create the updated website artifact with this project added
4. I'll then copy the new code and update my GitHub repository
```

### Method 2: Manually Edit the HTML (For Learning)

If you want to learn how to edit the code yourself:

1. Go to your GitHub repository
2. Click on `index.html`
3. Click the **pencil icon** (Edit this file)
4. Find the section with project cards (look for "projectsData")
5. Add this code AFTER the last project:

```javascript
{
  id: 4,
  title: 'Weekend Schedule Optimization',
  category: 'Healthcare Operations',
  description: 'Analyzed staff scheduling and workload distribution for residential care, reducing variance by 60% while improving care consistency.',
  tools: ['Google Sheets', 'SQL', 'Statistical Analysis'],
  outcomes: [
    'Reduced workload variance from 25% to <10%',
    'Eliminated 8-10 scheduling conflicts per weekend',
    'Improved care consistency for high-needs individuals'
  ],
  metrics: { individuals: '6', staff: '4', variance: '-60%' }
}
```

6. Scroll to bottom, click **"Commit changes"**
7. Your live website updates automatically in 1-2 minutes!

---

## OPTION B: Even Easier - Use Netlify (Drag & Drop)

### Why Netlify?
- Literally drag and drop files
- Automatic HTTPS (secure website)
- Free custom domain options
- Easier updates

### Steps for Netlify

#### Step 1: Save Your Website as File
1. Go to your portfolio chat: https://claude.ai/chat/b6553632-8b4a-4cff-873b-45fe72702c18
2. Copy the code from the artifact
3. Open **Notepad** (Windows) or **TextEdit** (Mac)
4. Paste the code
5. Save as: `index.html` (make sure it's `.html` not `.txt`)

#### Step 2: Sign Up for Netlify
1. Go to https://www.netlify.com
2. Click **"Sign up"**
3. Sign up with GitHub (easiest - uses your GitHub account)

#### Step 3: Deploy Your Site
1. After login, click **"Add new site"** → **"Deploy manually"**
2. **Drag your `index.html` file** into the upload box
3. Wait 10 seconds - Netlify deploys your site
4. You get a live URL like: `https://amazing-curie-123abc.netlify.app`

#### Step 4: Customize Your Domain (Optional)
1. Click **"Domain settings"**
2. Click **"Edit site name"**
3. Change to: `mary-healthcare-analytics` 
4. Your URL becomes: `https://mary-healthcare-analytics.netlify.app`

🎉 **Website is live and looks more professional than GitHub Pages!**

---

## Adding Your Google Sheets Portfolio Data

### What We Created Today
- Weekend Schedule Optimization Project Brief
- Complete data structure with 7 sheets
- SQL queries
- Portfolio talking points

### How to Add to Your Website

#### Option 1: Link to Google Sheets (Professional Showcase)
1. **Create Google Sheets workbook** with your project data:
   - Go to https://sheets.google.com
   - Create new spreadsheet
   - Name it: "Weekend Schedule Optimization Analysis"
   - Copy the sheet structures from the document I created today

2. **Make it publicly viewable**:
   - Click **"Share"** button (top right)
   - Click **"Change to anyone with the link"**
   - Set to **"Viewer"**
   - Copy the link

3. **Add to your portfolio website**:
   - In the project description, add a button/link:
   ```
   📊 View Interactive Analysis
   [Link to your Google Sheets]
   ```

#### Option 2: Embed Tableau Dashboard
Once you create your Tableau visualization:
1. Publish to **Tableau Public**
2. Get embed code
3. Add to your portfolio website
4. Visitors can interact with your dashboard directly on your site!

#### Option 3: Screenshots & PDF
1. Take screenshots of your Google Sheets analysis
2. Create PDF with key findings
3. Upload to GitHub repository in a `/projects` folder
4. Link from your portfolio

---

## Keeping Your Websites Editable

### Your websites ARE editable! Here's how:

#### For GitHub Pages:
1. Go to your repository: `github.com/your-username/portfolio`
2. Click `index.html`
3. Click pencil icon to edit
4. Make changes
5. Commit - site updates automatically!

#### For Netlify:
1. Edit your `index.html` file on your computer
2. Go to Netlify dashboard
3. Drag new file into "Deploys" section
4. Site updates in seconds!

#### Using Claude to Update:
1. Go to your portfolio chat
2. Say: "Claude, update my portfolio to add [new project/change section/etc]"
3. Claude creates new artifact with changes
4. Copy new code
5. Update GitHub or Netlify

---

## Recommended Workflow for Your Portfolio

### TODAY: Get One Site Live
1. Choose GitHub Pages OR Netlify (I recommend Netlify for ease)
2. Publish your Healthcare Analytics Portfolio
3. Test the live link
4. Share with one friend for feedback

### THIS WEEK: Add Weekend Schedule Project
1. Ask Claude to add the project to your portfolio website (use message template above)
2. Update your live site with new code
3. Create basic Google Sheets workbook with your schedule data
4. Link to it from portfolio

### NEXT WEEK: Build Out Project Details
1. Complete all 7 sheets in Google Sheets
2. Create 2-3 visualizations in Tableau
3. Write 1-page executive summary
4. Add screenshots to portfolio

### ONGOING: Portfolio Maintenance
Every time you complete a new project:
1. Go to your portfolio chat with Claude
2. Ask Claude to add the new project
3. Update your live site (takes 2 minutes)
4. Update LinkedIn with new portfolio link

---

## Custom Domain (Optional - Makes You Look Pro)

### Why Get Custom Domain?
Instead of: `mary-healthcare-analytics.netlify.app`
You get: `marysmithanalytics.com`

### How to Get One
1. **Buy domain** ($12/year):
   - Namecheap.com
   - Google Domains
   - GoDaddy
   
2. **Connect to Netlify**:
   - Netlify: Domain settings → Add custom domain
   - Follow instructions (takes 5 minutes)

3. **Free SSL certificate** included (secure https://)

**When to do this**: After you have 2-3 projects on your portfolio and are actively job searching. It signals you're serious!

---

## Quick Reference: Your Portfolio Ecosystem

```
YOUR PORTFOLIO SYSTEM:

1. CONTENT CREATION (Claude.ai)
   ↓
   Create/update projects with Claude
   Claude generates website code

2. STORAGE (GitHub)
   ↓
   Store code in GitHub repository
   Version control for changes
   Professional coding presence

3. HOSTING (Netlify or GitHub Pages)
   ↓
   Live website on internet
   Automatic updates when you change code
   Free SSL certificate (https)

4. ANALYTICS DATA (Google Sheets/Tableau)
   ↓
   Store detailed analysis
   Link from portfolio
   Demonstrate technical skills

5. PROFESSIONAL PRESENCE (LinkedIn)
   ↓
   Link to portfolio in headline
   Share projects as posts
   Drive traffic to your site
```

---

## Troubleshooting Common Issues

### "My site isn't showing up after publishing"
- **GitHub Pages**: Wait 5-10 minutes, clear browser cache
- **Netlify**: Should be instant - check deploy log for errors

### "I made changes but don't see them"
- Hard refresh: `Ctrl + F5` (Windows) or `Cmd + Shift + R` (Mac)
- Clear browser cache
- Check you saved/committed changes

### "The website looks broken"
- Make sure you copied ALL the code from Claude's artifact
- Check the browser console for errors (F12 → Console tab)
- Ask Claude: "My portfolio website looks broken, can you help debug?"

### "I can't find my GitHub repository"
- Go to: `github.com/your-username`
- All your repositories listed there

---

## Your Next Steps (Action Plan)

### ✅ Step 1 (Tonight - 15 minutes)
- [ ] Create GitHub account (if needed)
- [ ] Create portfolio repository
- [ ] Copy code from portfolio chat to GitHub
- [ ] Enable GitHub Pages
- [ ] TEST your live URL!

### ✅ Step 2 (This Weekend - 30 minutes)
- [ ] Ask Claude to add Weekend Schedule project to portfolio
- [ ] Update GitHub with new code
- [ ] Share portfolio link with one trusted person for feedback

### ✅ Step 3 (Next Week - 2 hours)
- [ ] Create Google Sheets with your schedule analysis
- [ ] Add at least 3 sheets with data
- [ ] Make sheet public (view only)
- [ ] Add link to portfolio

### ✅ Step 4 (Ongoing)
- [ ] Update LinkedIn headline with portfolio URL
- [ ] Add portfolio to resume
- [ ] Reference portfolio in job applications
- [ ] Ask Claude to add new projects as you complete them

---

## Sample LinkedIn Post When Your Portfolio is Live

```
🚀 Excited to share my Healthcare Analytics Portfolio!

As a Direct Support Professional transitioning into data analytics, I'm combining my healthcare domain expertise with technical skills in R, SQL, and Tableau.

Featured project: Weekend Schedule Optimization & Workload Analysis
→ Reduced staff workload variance by 60%
→ Improved care consistency for high-needs individuals
→ Eliminated scheduling conflicts using data-driven role optimization

Check it out: [your-portfolio-URL]

Currently completing Google Data Analytics Certificate through Merit America and actively seeking opportunities in:
✅ Healthcare Data Analytics
✅ Epic Credentialed Trainer roles
✅ Cardiac Rehabilitation Analytics

#DataAnalytics #HealthcareAnalytics #CareerTransition #EpicSystems
```

---

## Questions? Here's What to Ask Claude

**To update your portfolio**:
"Claude, add [project name] to my portfolio website from [chat URL]"

**To fix issues**:
"My portfolio website at [URL] isn't working - can you help debug?"

**To create new sections**:
"Add a 'Certifications' section to my portfolio showing my Google Data Analytics Certificate"

**To change design**:
"Update my portfolio color scheme to be more professional/modern/healthcare-themed"

---

## Final Tips

✅ **Start simple**: Get ONE website live today, perfect it later
✅ **Update regularly**: Add projects as you complete them
✅ **Get feedback**: Share with Merit America peers and mentors
✅ **Keep backups**: GitHub automatically saves all versions
✅ **Stay organized**: One repository for portfolio, separate for projects
✅ **Be proud**: Your portfolio shows your journey - that's valuable!

Your portfolio is a living document. It grows with you. Don't wait for it to be "perfect" before publishing!

**Let's get your first site live TODAY. Which method appeals to you: GitHub Pages or Netlify?**
