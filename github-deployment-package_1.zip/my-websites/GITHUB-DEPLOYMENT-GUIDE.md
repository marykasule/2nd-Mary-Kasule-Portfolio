# 📘 GitHub Deployment Guide

## Why GitHub?
- ✅ Free forever
- ✅ Professional portfolio piece
- ✅ Version control (track all your changes)
- ✅ Easy updates
- ✅ Free website hosting with GitHub Pages
- ✅ Backed by Microsoft

---

## 🚀 Method 1: Upload Through GitHub Website (Easiest for Beginners)

### Step 1: Create a GitHub Account
1. Go to https://github.com
2. Click "Sign Up"
3. Enter your email, create password, choose username
4. Verify your email

### Step 2: Create a New Repository
1. Click the **+** icon in top-right corner
2. Select **"New repository"**
3. Name it: `my-websites` (or any name you like)
4. Description: "My career journey and life planner websites"
5. Choose **Public** (required for free GitHub Pages hosting)
6. ✅ Check "Add a README file"
7. Click **"Create repository"**

### Step 3: Upload Your Files
1. In your new repository, click **"Add file"** → **"Upload files"**
2. Drag ALL the files from the `build` folder (not the folder itself, the contents inside)
3. Add commit message: "Initial website deployment"
4. Click **"Commit changes"**

### Step 4: Enable GitHub Pages
1. Go to your repository **Settings** (gear icon)
2. Click **"Pages"** in the left sidebar
3. Under "Source", select **"Deploy from a branch"**
4. Branch: Select **"main"** (or "master")
5. Folder: Select **"/ (root)"**
6. Click **"Save"**
7. Wait 2-3 minutes, then refresh the page
8. You'll see: "Your site is live at https://YOUR-USERNAME.github.io/my-websites/"

**Done! Your websites are now live!** 🎉

---

## 🛠️ Method 2: Using Git (More Professional - Recommended Long-term)

### Prerequisites
Install Git on your computer:
- **Windows**: Download from https://git-scm.com/download/win
- **Mac**: Open Terminal and type `git --version` (will auto-install)
- **Linux**: `sudo apt-get install git`

### Step-by-Step Git Deployment

**1. Create Repository on GitHub**
- Same as Method 1, Steps 1-2 above
- Don't check "Add a README file" this time

**2. Open Terminal/Command Prompt**
- Windows: Press Windows+R, type `cmd`, press Enter
- Mac: Press Cmd+Space, type `terminal`, press Enter

**3. Navigate to Your Website Folder**
```bash
cd path/to/your/downloaded/my-websites
```

**4. Initialize Git and Push to GitHub**
```bash
# Initialize git in this folder
git init

# Add all files
git add .

# Create your first commit
git commit -m "Initial commit - My career and life websites"

# Connect to your GitHub repository (replace YOUR-USERNAME and my-websites)
git remote add origin https://github.com/YOUR-USERNAME/my-websites.git

# Push to GitHub
git branch -M main
git push -u origin main
```

**5. Enable GitHub Pages**
- Follow Step 4 from Method 1 above

---

## 📝 Updating Your Website Later

### Using GitHub Website:
1. Go to your repository
2. Navigate to the file you want to change
3. Click the pencil icon ✏️ to edit
4. Make your changes
5. Scroll down and click "Commit changes"
6. Your site updates automatically in 1-2 minutes!

### Using Git (if you went with Method 2):
```bash
# After making changes to your files
git add .
git commit -m "Updated journal entries"
git push
```

---

## 🌐 Your Website URLs

After deployment, your sites will be accessible at:

**Home Page:**
```
https://YOUR-USERNAME.github.io/my-websites/
```

**Career Journey:**
```
https://YOUR-USERNAME.github.io/my-websites/career
```

**Life Journal:**
```
https://YOUR-USERNAME.github.io/my-websites/journal
```

---

## 🎯 Custom Domain (Optional)

Want your own domain like `marycareer.com`?

1. Buy a domain from:
   - Namecheap (around $10/year)
   - Google Domains
   - GoDaddy

2. In your GitHub repository:
   - Settings → Pages → Custom domain
   - Enter your domain
   - Follow the DNS configuration instructions

---

## 📱 What's Included in Your GitHub Repository?

```
my-websites/
├── build/                  (Your compiled website files)
│   ├── index.html         (Home page)
│   ├── static/            (CSS and JavaScript)
│   └── favicon.ico        (Tab icon)
├── src/                   (Source code - for making changes)
│   ├── App.js
│   ├── CareerJourney.js
│   └── LifeJournal.js
├── package.json           (Project configuration)
└── README.md             (Project description)
```

---

## ⚠️ Important Notes

### About Your Data:
- Journal entries, budgets, photos saved in **browser LocalStorage**
- Each device has separate data
- Not stored on GitHub (for privacy!)
- To share data between devices, you'd need to add a database (ask me if interested!)

### Keeping Source Code:
- Upload the ENTIRE `my-websites` folder to GitHub (not just build)
- This lets you make changes and rebuild later
- The `build` folder is what visitors see
- The `src` folder is for making edits

---

## 🆘 Common Issues

**"Page not found" error?**
- Make sure you uploaded files from INSIDE the build folder
- Check that GitHub Pages is enabled
- Wait 2-3 minutes for deployment

**Site looks broken?**
- Make sure you selected "/ (root)" as the folder
- Check that all files uploaded correctly

**Want to update content?**
- Edit the source files in `src/`
- Run `npm run build` on your computer
- Upload new build files to GitHub

---

## 📚 Next Steps

After deploying:

1. **Add a README**: Describe your projects
2. **Add a .gitignore**: Prevent uploading unnecessary files
3. **Learn Git basics**: Version control is valuable for your data analytics career!
4. **Add to resume**: "Built and deployed responsive web applications using React, hosted on GitHub Pages"

---

## 💡 Pro Tips

1. **Portfolio Boost**: This is a real project for your resume!
2. **Show Hiring Managers**: Direct link to your career journey
3. **Version Control**: Every change is tracked
4. **Free**: No hosting fees, ever
5. **Professional**: Shows technical competence

---

**Need Help?** 
- GitHub has great documentation: https://docs.github.com
- Or just ask me - I'm happy to help troubleshoot!

Ready to deploy? Start with Method 1 (easiest) and graduate to Method 2 when you're comfortable! 🚀
