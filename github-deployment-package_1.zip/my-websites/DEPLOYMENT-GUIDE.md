# 🚀 Deployment Guide - Mary's Websites

Your websites are built and ready to deploy! Here are your options:

## ⚡ Option 1: Netlify Drop (EASIEST - 2 minutes, totally free)

1. Go to https://app.netlify.com/drop
2. Drag and drop the entire `build` folder onto the page
3. Done! You'll get a live URL like: https://random-name-12345.netlify.app
4. Optional: Click "Domain settings" to customize your URL

**Pros:** Instant, free, no account needed
**Cons:** Random URL unless you customize it

---

## 🎯 Option 2: Netlify (with account - better features)

1. Create free account at https://www.netlify.com
2. Click "Add new site" → "Deploy manually"
3. Drag the `build` folder
4. You get: Custom domain, automatic backups, easy updates

**Pros:** Custom domain, professional, easy updates
**Cons:** Requires account (but free!)

---

## 💙 Option 3: Vercel (alternative to Netlify)

1. Create account at https://vercel.com
2. Click "Add New..." → "Project"
3. Click "Continue with GitHub" OR upload the `build` folder
4. Deploy!

**Pros:** Fast, modern, great for React apps
**Cons:** Requires account

---

## 📦 Option 4: GitHub Pages (best for long-term)

1. Create GitHub account at https://github.com
2. Create new repository called "my-websites"
3. Upload the contents of the `build` folder
4. Go to Settings → Pages → Source: main branch
5. Your site will be at: https://yourusername.github.io/my-websites

**Pros:** Free forever, backed by Microsoft, version control
**Cons:** Slightly more technical

---

## 🏠 What's in the build folder?

The `build` folder contains your complete websites as static files:
- All HTML, CSS, and JavaScript compiled and optimized
- Ready to work on any web server
- Works on phones, tablets, and computers
- All your data saves in the browser (LocalStorage)

---

## 💡 Important Notes:

1. **Data Storage**: Your journal entries, budget, etc. save in your browser's LocalStorage
   - Data persists on the device you're using
   - Clearing browser data will delete your content
   - Each device (phone, computer) will have separate data

2. **Accessing Your Sites**:
   - Home page: Choose between Career or Journal site
   - Career site: /career
   - Journal site: /journal

3. **Updates**: To update your sites later:
   - Make changes to the source files
   - Run `npm run build` again
   - Re-upload the new `build` folder

---

## 🆘 Need Help?

If you encounter any issues:
1. Make sure you're uploading the `build` folder, not the whole project
2. Try a different browser if the site doesn't load
3. Clear your browser cache and try again

---

## 🎨 Next Steps (Optional):

Want to customize further?
- Edit the source files in `src/` folder
- Change colors by modifying the gradient classes
- Add more sections or features
- Run `npm start` locally to see changes before building

---

**Ready to deploy?** 

I recommend Netlify Drop for the fastest deployment:
👉 https://app.netlify.com/drop

Just drag the `build` folder there and you're live in seconds!
