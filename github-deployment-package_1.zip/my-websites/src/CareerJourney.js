import React, { useState, useEffect } from 'react';
import { Upload, Edit2, Save, Plus, X, Briefcase, Target, Code, TrendingUp, Award } from 'lucide-react';

export default function CareerJourney() {
  const [activeSection, setActiveSection] = useState('overview');
  const [isEditing, setIsEditing] = useState(false);
  const [data, setData] = useState({
    overview: {
      title: "My Career Transformation",
      content: "Transitioning from massage therapy to healthcare data analytics, combining my deep healthcare domain knowledge with technical data skills. Currently completing the Google Data Analytics Certificate through Merit America, with a focus on cardiac rehabilitation analytics and Epic systems.",
      image: null
    },
    journey: {
      milestones: [
        {
          id: 1,
          date: "2024",
          title: "Starting Data Analytics Journey",
          description: "Enrolled in Merit America's Google Data Analytics Certificate program through Coursera. Beginning intensive study of R programming, SQL, and Tableau visualization.",
          image: null
        },
        {
          id: 2,
          date: "Current",
          title: "Course 7: R Programming & RStudio",
          description: "Deep diving into R programming fundamentals, data structures, tibbles, and statistical analysis. Building practical skills through hands-on projects.",
          image: null
        },
        {
          id: 3,
          date: "In Progress",
          title: "Portfolio Development",
          description: "Working on U.S. Electric Vehicle Market Share analysis using R, SQL, and Tableau. Creating comprehensive dashboards that demonstrate end-to-end data analytics capabilities.",
          image: null
        }
      ]
    },
    skills: {
      technical: [
        { name: "R Programming", level: "Learning", priority: "High" },
        { name: "SQL", level: "Learning", priority: "High" },
        { name: "Tableau", level: "Learning", priority: "High" },
        { name: "RStudio", level: "Learning", priority: "High" },
        { name: "Data Visualization", level: "Developing", priority: "Medium" },
        { name: "Statistical Analysis", level: "Learning", priority: "Medium" }
      ],
      healthcare: [
        { name: "Healthcare Operations", level: "Expert", priority: "High" },
        { name: "Client Relationship Management", level: "Expert", priority: "High" },
        { name: "Cardiac Rehabilitation Knowledge", level: "Proficient", priority: "High" },
        { name: "Epic Systems Understanding", level: "Learning", priority: "High" }
      ]
    },
    goals: {
      shortTerm: [
        "Complete Google Data Analytics Certificate",
        "Build 3-5 portfolio projects demonstrating R, SQL, and Tableau proficiency",
        "Master cardiac rehabilitation analytics metrics and KPIs",
        "Develop go-to-market strategy skills"
      ],
      longTerm: [
        "Secure Epic Credentialed Trainer position",
        "Specialize in cardiac rehabilitation analytics",
        "Work at Virginia Department of Health or similar healthcare organization",
        "Bridge healthcare domain expertise with data analytics leadership"
      ]
    },
    portfolio: [],
    targetRoles: {
      roles: [
        {
          title: "Epic Credentialed Trainer",
          organization: "Virginia Department of Health",
          why: "Combines healthcare knowledge, training expertise, and technical systems proficiency"
        },
        {
          title: "Cardiac Rehabilitation Analyst",
          organization: "Healthcare Systems",
          why: "Leverages domain knowledge while building data analytics career"
        },
        {
          title: "Healthcare Data Analyst",
          organization: "Health Organizations",
          why: "Perfect intersection of technical skills and healthcare expertise"
        }
      ]
    }
  });

  useEffect(() => {
    const savedData = localStorage.getItem('careerJourneyData');
    if (savedData) {
      setData(JSON.parse(savedData));
    }
  }, []);

  const saveData = () => {
    localStorage.setItem('careerJourneyData', JSON.stringify(data));
    setIsEditing(false);
  };

  const handleImageUpload = (section, id = null) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
          const newData = { ...data };
          if (id !== null) {
            const milestone = newData.journey.milestones.find(m => m.id === id);
            if (milestone) milestone.image = event.target.result;
          } else if (section === 'overview') {
            newData.overview.image = event.target.result;
          } else if (section === 'portfolio') {
            // Handle portfolio images separately
          }
          setData(newData);
          localStorage.setItem('careerJourneyData', JSON.stringify(newData));
        };
        reader.readAsDataURL(file);
      }
    };
    input.click();
  };

  const addMilestone = () => {
    const newMilestone = {
      id: Date.now(),
      date: "New Date",
      title: "New Milestone",
      description: "Add description here...",
      image: null
    };
    const newData = { ...data };
    newData.journey.milestones.push(newMilestone);
    setData(newData);
  };

  const addPortfolioProject = () => {
    const newProject = {
      id: Date.now(),
      title: "New Project",
      description: "Project description...",
      technologies: "R, SQL, Tableau",
      link: "",
      image: null
    };
    const newData = { ...data };
    if (!newData.portfolio) newData.portfolio = [];
    newData.portfolio.push(newProject);
    setData(newData);
  };

  const updateField = (section, field, value, id = null) => {
    const newData = { ...data };
    if (id !== null) {
      if (section === 'journey') {
        const milestone = newData.journey.milestones.find(m => m.id === id);
        if (milestone) milestone[field] = value;
      } else if (section === 'portfolio') {
        const project = newData.portfolio.find(p => p.id === id);
        if (project) project[field] = value;
      }
    } else {
      if (typeof newData[section][field] === 'object' && !Array.isArray(newData[section][field])) {
        newData[section][field] = { ...newData[section][field], ...value };
      } else {
        newData[section][field] = value;
      }
    }
    setData(newData);
  };

  const deleteMilestone = (id) => {
    const newData = { ...data };
    newData.journey.milestones = newData.journey.milestones.filter(m => m.id !== id);
    setData(newData);
  };

  const deleteProject = (id) => {
    const newData = { ...data };
    newData.portfolio = newData.portfolio.filter(p => p.id !== id);
    setData(newData);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                Mary's Career Journey
              </h1>
              <p className="text-gray-600 mt-1">From Healthcare Professional to Data Analytics Leader</p>
            </div>
            <button
              onClick={() => isEditing ? saveData() : setIsEditing(true)}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:shadow-lg transition-all"
            >
              {isEditing ? <><Save className="w-5 h-5" /> Save Changes</> : <><Edit2 className="w-5 h-5" /> Edit Mode</>}
            </button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b sticky top-[88px] z-40">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex gap-1 overflow-x-auto py-2">
            {[
              { id: 'overview', label: 'Overview', icon: Briefcase },
              { id: 'journey', label: 'My Journey', icon: TrendingUp },
              { id: 'skills', label: 'Skills', icon: Award },
              { id: 'goals', label: 'Goals', icon: Target },
              { id: 'portfolio', label: 'Portfolio', icon: Code },
              { id: 'targetRoles', label: 'Target Roles', icon: Briefcase }
            ].map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveSection(id)}
                className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all whitespace-nowrap ${
                  activeSection === id
                    ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <Icon className="w-4 h-4" />
                {label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Overview Section */}
        {activeSection === 'overview' && (
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <div className="flex justify-between items-start mb-6">
              <h2 className="text-3xl font-bold text-gray-800">Career Overview</h2>
              {isEditing && (
                <button
                  onClick={() => handleImageUpload('overview')}
                  className="flex items-center gap-2 px-4 py-2 bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200"
                >
                  <Upload className="w-4 h-4" />
                  Upload Photo
                </button>
              )}
            </div>
            
            {data.overview.image && (
              <img src={data.overview.image} alt="Overview" className="w-full h-64 object-cover rounded-lg mb-6" />
            )}
            
            {isEditing ? (
              <>
                <input
                  type="text"
                  value={data.overview.title}
                  onChange={(e) => updateField('overview', 'title', e.target.value)}
                  className="w-full text-2xl font-semibold mb-4 p-2 border-2 border-purple-200 rounded-lg"
                />
                <textarea
                  value={data.overview.content}
                  onChange={(e) => updateField('overview', 'content', e.target.value)}
                  className="w-full h-40 p-4 border-2 border-purple-200 rounded-lg"
                />
              </>
            ) : (
              <>
                <h3 className="text-2xl font-semibold text-purple-600 mb-4">{data.overview.title}</h3>
                <p className="text-gray-700 text-lg leading-relaxed">{data.overview.content}</p>
              </>
            )}
          </div>
        )}

        {/* Journey Section */}
        {activeSection === 'journey' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-3xl font-bold text-gray-800">My Journey Timeline</h2>
              {isEditing && (
                <button
                  onClick={addMilestone}
                  className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:shadow-lg"
                >
                  <Plus className="w-4 h-4" />
                  Add Milestone
                </button>
              )}
            </div>

            {data.journey.milestones.map((milestone, index) => (
              <div key={milestone.id} className="bg-white rounded-2xl shadow-xl p-8 relative">
                {isEditing && (
                  <button
                    onClick={() => deleteMilestone(milestone.id)}
                    className="absolute top-4 right-4 p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
                
                <div className="flex gap-6">
                  <div className="flex-shrink-0">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-r from-purple-600 to-pink-600 flex items-center justify-center text-white font-bold text-xl">
                      {index + 1}
                    </div>
                  </div>
                  
                  <div className="flex-1">
                    {isEditing ? (
                      <>
                        <input
                          type="text"
                          value={milestone.date}
                          onChange={(e) => updateField('journey', 'date', e.target.value, milestone.id)}
                          className="text-purple-600 font-semibold mb-2 p-2 border-2 border-purple-200 rounded w-full"
                        />
                        <input
                          type="text"
                          value={milestone.title}
                          onChange={(e) => updateField('journey', 'title', e.target.value, milestone.id)}
                          className="text-2xl font-bold mb-3 p-2 border-2 border-purple-200 rounded w-full"
                        />
                        <textarea
                          value={milestone.description}
                          onChange={(e) => updateField('journey', 'description', e.target.value, milestone.id)}
                          className="w-full h-24 p-3 border-2 border-purple-200 rounded"
                        />
                        <button
                          onClick={() => handleImageUpload('journey', milestone.id)}
                          className="mt-3 flex items-center gap-2 px-4 py-2 bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200"
                        >
                          <Upload className="w-4 h-4" />
                          Upload Image
                        </button>
                      </>
                    ) : (
                      <>
                        <p className="text-purple-600 font-semibold mb-2">{milestone.date}</p>
                        <h3 className="text-2xl font-bold text-gray-800 mb-3">{milestone.title}</h3>
                        <p className="text-gray-700 leading-relaxed">{milestone.description}</p>
                      </>
                    )}
                    
                    {milestone.image && (
                      <img src={milestone.image} alt={milestone.title} className="mt-4 w-full h-48 object-cover rounded-lg" />
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Skills Section */}
        {activeSection === 'skills' && (
          <div className="space-y-6">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Skills & Expertise</h2>
            
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h3 className="text-2xl font-bold text-purple-600 mb-6">Technical Skills</h3>
              <div className="space-y-4">
                {data.skills.technical.map((skill, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-purple-50 rounded-lg">
                    <div className="flex-1">
                      <p className="font-semibold text-gray-800">{skill.name}</p>
                      <p className="text-sm text-gray-600">Level: {skill.level}</p>
                    </div>
                    <span className={`px-4 py-1 rounded-full text-sm font-medium ${
                      skill.priority === 'High' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'
                    }`}>
                      {skill.priority} Priority
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h3 className="text-2xl font-bold text-pink-600 mb-6">Healthcare Domain Expertise</h3>
              <div className="space-y-4">
                {data.skills.healthcare.map((skill, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-pink-50 rounded-lg">
                    <div className="flex-1">
                      <p className="font-semibold text-gray-800">{skill.name}</p>
                      <p className="text-sm text-gray-600">Level: {skill.level}</p>
                    </div>
                    <span className={`px-4 py-1 rounded-full text-sm font-medium ${
                      skill.priority === 'High' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'
                    }`}>
                      {skill.priority} Priority
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Goals Section */}
        {activeSection === 'goals' && (
          <div className="space-y-6">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Career Goals</h2>
            
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h3 className="text-2xl font-bold text-purple-600 mb-6">Short-Term Goals</h3>
              <div className="space-y-3">
                {data.goals.shortTerm.map((goal, index) => (
                  <div key={index} className="flex items-start gap-3 p-4 bg-purple-50 rounded-lg">
                    <div className="w-6 h-6 rounded-full bg-purple-600 text-white flex items-center justify-center flex-shrink-0 mt-0.5">
                      ✓
                    </div>
                    <p className="text-gray-800 flex-1">{goal}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h3 className="text-2xl font-bold text-pink-600 mb-6">Long-Term Goals</h3>
              <div className="space-y-3">
                {data.goals.longTerm.map((goal, index) => (
                  <div key={index} className="flex items-start gap-3 p-4 bg-pink-50 rounded-lg">
                    <div className="w-6 h-6 rounded-full bg-pink-600 text-white flex items-center justify-center flex-shrink-0 mt-0.5">
                      ★
                    </div>
                    <p className="text-gray-800 flex-1">{goal}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Portfolio Section */}
        {activeSection === 'portfolio' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-3xl font-bold text-gray-800">Portfolio Projects</h2>
              {isEditing && (
                <button
                  onClick={addPortfolioProject}
                  className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:shadow-lg"
                >
                  <Plus className="w-4 h-4" />
                  Add Project
                </button>
              )}
            </div>

            {(!data.portfolio || data.portfolio.length === 0) && (
              <div className="bg-white rounded-2xl shadow-xl p-12 text-center">
                <Code className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                <p className="text-gray-600 text-lg">No projects yet. Click "Add Project" to get started!</p>
              </div>
            )}

            {data.portfolio && data.portfolio.map((project) => (
              <div key={project.id} className="bg-white rounded-2xl shadow-xl p-8 relative">
                {isEditing && (
                  <button
                    onClick={() => deleteProject(project.id)}
                    className="absolute top-4 right-4 p-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
                
                {isEditing ? (
                  <div className="space-y-4">
                    <input
                      type="text"
                      value={project.title}
                      onChange={(e) => updateField('portfolio', 'title', e.target.value, project.id)}
                      placeholder="Project Title"
                      className="w-full text-2xl font-bold p-2 border-2 border-purple-200 rounded"
                    />
                    <textarea
                      value={project.description}
                      onChange={(e) => updateField('portfolio', 'description', e.target.value, project.id)}
                      placeholder="Project Description"
                      className="w-full h-24 p-3 border-2 border-purple-200 rounded"
                    />
                    <input
                      type="text"
                      value={project.technologies}
                      onChange={(e) => updateField('portfolio', 'technologies', e.target.value, project.id)}
                      placeholder="Technologies Used (e.g., R, SQL, Tableau)"
                      className="w-full p-2 border-2 border-purple-200 rounded"
                    />
                    <input
                      type="text"
                      value={project.link}
                      onChange={(e) => updateField('portfolio', 'link', e.target.value, project.id)}
                      placeholder="Project Link (optional)"
                      className="w-full p-2 border-2 border-purple-200 rounded"
                    />
                  </div>
                ) : (
                  <>
                    <h3 className="text-2xl font-bold text-gray-800 mb-3">{project.title}</h3>
                    <p className="text-gray-700 mb-4">{project.description}</p>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.technologies.split(',').map((tech, i) => (
                        <span key={i} className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm">
                          {tech.trim()}
                        </span>
                      ))}
                    </div>
                    {project.link && (
                      <a href={project.link} target="_blank" rel="noopener noreferrer" className="text-purple-600 hover:underline">
                        View Project →
                      </a>
                    )}
                  </>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Target Roles Section */}
        {activeSection === 'targetRoles' && (
          <div className="space-y-6">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Target Career Roles</h2>
            
            {data.targetRoles.roles.map((role, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-xl p-8">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-r from-purple-600 to-pink-600 flex items-center justify-center flex-shrink-0">
                    <Briefcase className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold text-gray-800 mb-2">{role.title}</h3>
                    <p className="text-purple-600 font-semibold mb-3">{role.organization}</p>
                    <p className="text-gray-700 leading-relaxed"><strong>Why this role:</strong> {role.why}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}