import React, { useState, useEffect } from 'react';
import { Calendar, DollarSign, CheckSquare, BookOpen, Camera, Plus, Edit2, Save, Trash2, X } from 'lucide-react';

export default function LifeJournal() {
  const [activeTab, setActiveTab] = useState('journal');
  const [isEditing, setIsEditing] = useState(false);
  const [data, setData] = useState({
    journal: {
      entries: []
    },
    reminders: {
      tasks: []
    },
    budget: {
      income: [],
      expenses: [],
      savings: []
    },
    gallery: {
      photos: []
    },
    goals: {
      items: []
    }
  });

  useEffect(() => {
    const savedData = localStorage.getItem('lifeJournalData');
    if (savedData) {
      setData(JSON.parse(savedData));
    }
  }, []);

  const saveData = () => {
    localStorage.setItem('lifeJournalData', JSON.stringify(data));
  };

  useEffect(() => {
    saveData();
  }, [data]);

  // Journal Functions
  const addJournalEntry = () => {
    const newEntry = {
      id: Date.now(),
      date: new Date().toLocaleDateString(),
      title: 'New Entry',
      content: '',
      mood: '😊',
      tags: []
    };
    setData(prev => ({
      ...prev,
      journal: {
        ...prev.journal,
        entries: [newEntry, ...prev.journal.entries]
      }
    }));
  };

  const updateJournalEntry = (id, field, value) => {
    setData(prev => ({
      ...prev,
      journal: {
        ...prev.journal,
        entries: prev.journal.entries.map(entry =>
          entry.id === id ? { ...entry, [field]: value } : entry
        )
      }
    }));
  };

  const deleteJournalEntry = (id) => {
    setData(prev => ({
      ...prev,
      journal: {
        ...prev.journal,
        entries: prev.journal.entries.filter(entry => entry.id !== id)
      }
    }));
  };

  // Reminder Functions
  const addReminder = () => {
    const newTask = {
      id: Date.now(),
      task: 'New Task',
      dueDate: new Date().toISOString().split('T')[0],
      priority: 'Medium',
      completed: false,
      category: 'Personal'
    };
    setData(prev => ({
      ...prev,
      reminders: {
        ...prev.reminders,
        tasks: [...prev.reminders.tasks, newTask]
      }
    }));
  };

  const updateReminder = (id, field, value) => {
    setData(prev => ({
      ...prev,
      reminders: {
        ...prev.reminders,
        tasks: prev.reminders.tasks.map(task =>
          task.id === id ? { ...task, [field]: value } : task
        )
      }
    }));
  };

  const deleteReminder = (id) => {
    setData(prev => ({
      ...prev,
      reminders: {
        ...prev.reminders,
        tasks: prev.reminders.tasks.filter(task => task.id !== id)
      }
    }));
  };

  const toggleTaskComplete = (id) => {
    setData(prev => ({
      ...prev,
      reminders: {
        ...prev.reminders,
        tasks: prev.reminders.tasks.map(task =>
          task.id === id ? { ...task, completed: !task.completed } : task
        )
      }
    }));
  };

  // Budget Functions
  const addBudgetItem = (category) => {
    const newItem = {
      id: Date.now(),
      name: category === 'income' ? 'New Income Source' : category === 'expenses' ? 'New Expense' : 'New Savings Goal',
      amount: 0,
      frequency: 'Monthly',
      category: category === 'expenses' ? 'General' : '',
      date: new Date().toISOString().split('T')[0]
    };
    setData(prev => ({
      ...prev,
      budget: {
        ...prev.budget,
        [category]: [...prev.budget[category], newItem]
      }
    }));
  };

  const updateBudgetItem = (category, id, field, value) => {
    setData(prev => ({
      ...prev,
      budget: {
        ...prev.budget,
        [category]: prev.budget[category].map(item =>
          item.id === id ? { ...item, [field]: value } : item
        )
      }
    }));
  };

  const deleteBudgetItem = (category, id) => {
    setData(prev => ({
      ...prev,
      budget: {
        ...prev.budget,
        [category]: prev.budget[category].filter(item => item.id !== id)
      }
    }));
  };

  // Photo Functions
  const handlePhotoUpload = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.multiple = true;
    input.onchange = (e) => {
      const files = Array.from(e.target.files);
      files.forEach(file => {
        const reader = new FileReader();
        reader.onload = (event) => {
          const newPhoto = {
            id: Date.now() + Math.random(),
            src: event.target.result,
            caption: '',
            date: new Date().toLocaleDateString()
          };
          setData(prev => ({
            ...prev,
            gallery: {
              ...prev.gallery,
              photos: [newPhoto, ...prev.gallery.photos]
            }
          }));
        };
        reader.readAsDataURL(file);
      });
    };
    input.click();
  };

  const updatePhotoCaption = (id, caption) => {
    setData(prev => ({
      ...prev,
      gallery: {
        ...prev.gallery,
        photos: prev.gallery.photos.map(photo =>
          photo.id === id ? { ...photo, caption } : photo
        )
      }
    }));
  };

  const deletePhoto = (id) => {
    setData(prev => ({
      ...prev,
      gallery: {
        ...prev.gallery,
        photos: prev.gallery.photos.filter(photo => photo.id !== id)
      }
    }));
  };

  // Goals Functions
  const addGoal = () => {
    const newGoal = {
      id: Date.now(),
      title: 'New Goal',
      description: '',
      deadline: new Date().toISOString().split('T')[0],
      progress: 0,
      category: 'Personal'
    };
    setData(prev => ({
      ...prev,
      goals: {
        ...prev.goals,
        items: [...prev.goals.items, newGoal]
      }
    }));
  };

  const updateGoal = (id, field, value) => {
    setData(prev => ({
      ...prev,
      goals: {
        ...prev.goals,
        items: prev.goals.items.map(goal =>
          goal.id === id ? { ...goal, [field]: value } : goal
        )
      }
    }));
  };

  const deleteGoal = (id) => {
    setData(prev => ({
      ...prev,
      goals: {
        ...prev.goals,
        items: prev.goals.items.filter(goal => goal.id !== id)
      }
    }));
  };

  // Calculate budget totals
  const calculateTotal = (category) => {
    return data.budget[category].reduce((sum, item) => sum + parseFloat(item.amount || 0), 0);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Header */}
      <header className="bg-white shadow-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            My Life Journal & Planner
          </h1>
          <p className="text-gray-600 mt-1">Organize your thoughts, goals, and finances</p>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="bg-white border-b sticky top-[88px] z-40 shadow-sm">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex gap-2 overflow-x-auto py-3">
            {[
              { id: 'journal', label: 'Journal', icon: BookOpen },
              { id: 'reminders', label: 'Reminders & Tasks', icon: CheckSquare },
              { id: 'budget', label: 'Budget Tracker', icon: DollarSign },
              { id: 'goals', label: 'Goals', icon: Calendar },
              { id: 'gallery', label: 'Photo Gallery', icon: Camera }
            ].map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id)}
                className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-all whitespace-nowrap ${
                  activeTab === id
                    ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <Icon className="w-4 h-4" />
                {label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Journal Tab */}
        {activeTab === 'journal' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-3xl font-bold text-gray-800">Journal Entries</h2>
              <button
                onClick={addJournalEntry}
                className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:shadow-lg transition-all"
              >
                <Plus className="w-5 h-5" />
                New Entry
              </button>
            </div>

            {data.journal.entries.length === 0 && (
              <div className="bg-white rounded-2xl shadow-xl p-12 text-center">
                <BookOpen className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                <p className="text-gray-600 text-lg">No journal entries yet. Start writing your story!</p>
              </div>
            )}

            {data.journal.entries.map(entry => (
              <div key={entry.id} className="bg-white rounded-2xl shadow-xl p-8">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{entry.mood}</span>
                    <div>
                      <input
                        type="text"
                        value={entry.title}
                        onChange={(e) => updateJournalEntry(entry.id, 'title', e.target.value)}
                        className="text-2xl font-bold text-gray-800 border-b-2 border-transparent hover:border-blue-200 focus:border-blue-500 outline-none"
                      />
                      <p className="text-sm text-gray-500">{entry.date}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => deleteJournalEntry(entry.id)}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
                
                <textarea
                  value={entry.content}
                  onChange={(e) => updateJournalEntry(entry.id, 'content', e.target.value)}
                  placeholder="Write your thoughts here..."
                  className="w-full h-40 p-4 border-2 border-gray-200 rounded-lg focus:border-blue-500 outline-none resize-none"
                />
                
                <div className="mt-4 flex items-center gap-3">
                  <label className="text-sm text-gray-600">Mood:</label>
                  <select
                    value={entry.mood}
                    onChange={(e) => updateJournalEntry(entry.id, 'mood', e.target.value)}
                    className="px-3 py-1 border-2 border-gray-200 rounded-lg"
                  >
                    <option value="😊">😊 Happy</option>
                    <option value="😌">😌 Calm</option>
                    <option value="😢">😢 Sad</option>
                    <option value="😡">😡 Angry</option>
                    <option value="😰">😰 Anxious</option>
                    <option value="🤔">🤔 Thoughtful</option>
                    <option value="💪">💪 Motivated</option>
                    <option value="😴">😴 Tired</option>
                  </select>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Reminders Tab */}
        {activeTab === 'reminders' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-3xl font-bold text-gray-800">Tasks & Reminders</h2>
              <button
                onClick={addReminder}
                className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:shadow-lg transition-all"
              >
                <Plus className="w-5 h-5" />
                Add Task
              </button>
            </div>

            {data.reminders.tasks.length === 0 && (
              <div className="bg-white rounded-2xl shadow-xl p-12 text-center">
                <CheckSquare className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                <p className="text-gray-600 text-lg">No tasks yet. Add your first reminder!</p>
              </div>
            )}

            <div className="grid gap-4">
              {data.reminders.tasks.map(task => (
                <div
                  key={task.id}
                  className={`bg-white rounded-xl shadow-lg p-6 ${task.completed ? 'opacity-60' : ''}`}
                >
                  <div className="flex items-start gap-4">
                    <input
                      type="checkbox"
                      checked={task.completed}
                      onChange={() => toggleTaskComplete(task.id)}
                      className="w-6 h-6 mt-1 accent-blue-600 cursor-pointer"
                    />
                    
                    <div className="flex-1">
                      <input
                        type="text"
                        value={task.task}
                        onChange={(e) => updateReminder(task.id, 'task', e.target.value)}
                        className={`text-xl font-semibold border-b-2 border-transparent hover:border-blue-200 focus:border-blue-500 outline-none w-full ${
                          task.completed ? 'line-through' : ''
                        }`}
                      />
                      
                      <div className="flex flex-wrap gap-3 mt-3">
                        <div>
                          <label className="text-xs text-gray-600 block mb-1">Due Date:</label>
                          <input
                            type="date"
                            value={task.dueDate}
                            onChange={(e) => updateReminder(task.id, 'dueDate', e.target.value)}
                            className="px-3 py-1 border-2 border-gray-200 rounded-lg text-sm"
                          />
                        </div>
                        
                        <div>
                          <label className="text-xs text-gray-600 block mb-1">Priority:</label>
                          <select
                            value={task.priority}
                            onChange={(e) => updateReminder(task.id, 'priority', e.target.value)}
                            className="px-3 py-1 border-2 border-gray-200 rounded-lg text-sm"
                          >
                            <option value="Low">Low</option>
                            <option value="Medium">Medium</option>
                            <option value="High">High</option>
                          </select>
                        </div>
                        
                        <div>
                          <label className="text-xs text-gray-600 block mb-1">Category:</label>
                          <select
                            value={task.category}
                            onChange={(e) => updateReminder(task.id, 'category', e.target.value)}
                            className="px-3 py-1 border-2 border-gray-200 rounded-lg text-sm"
                          >
                            <option value="Personal">Personal</option>
                            <option value="Work">Work</option>
                            <option value="Health">Health</option>
                            <option value="Finance">Finance</option>
                            <option value="Study">Study</option>
                          </select>
                        </div>
                      </div>
                    </div>
                    
                    <button
                      onClick={() => deleteReminder(task.id)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Budget Tab */}
        {activeTab === 'budget' && (
          <div className="space-y-6">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Budget Tracker</h2>
            
            {/* Summary Cards */}
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-2xl shadow-xl p-6 text-white">
                <p className="text-sm opacity-90 mb-2">Total Income</p>
                <p className="text-4xl font-bold">${calculateTotal('income').toFixed(2)}</p>
              </div>
              <div className="bg-gradient-to-br from-red-500 to-red-600 rounded-2xl shadow-xl p-6 text-white">
                <p className="text-sm opacity-90 mb-2">Total Expenses</p>
                <p className="text-4xl font-bold">${calculateTotal('expenses').toFixed(2)}</p>
              </div>
              <div className="bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl shadow-xl p-6 text-white">
                <p className="text-sm opacity-90 mb-2">Net Balance</p>
                <p className="text-4xl font-bold">
                  ${(calculateTotal('income') - calculateTotal('expenses')).toFixed(2)}
                </p>
              </div>
            </div>

            {/* Income Section */}
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-bold text-green-600">Income Sources</h3>
                <button
                  onClick={() => addBudgetItem('income')}
                  className="flex items-center gap-2 px-4 py-2 bg-green-100 text-green-700 rounded-lg hover:bg-green-200"
                >
                  <Plus className="w-4 h-4" />
                  Add Income
                </button>
              </div>
              
              <div className="space-y-3">
                {data.budget.income.map(item => (
                  <div key={item.id} className="flex items-center gap-4 p-4 bg-green-50 rounded-lg">
                    <input
                      type="text"
                      value={item.name}
                      onChange={(e) => updateBudgetItem('income', item.id, 'name', e.target.value)}
                      className="flex-1 px-3 py-2 border-2 border-green-200 rounded-lg"
                      placeholder="Income source"
                    />
                    <input
                      type="number"
                      value={item.amount}
                      onChange={(e) => updateBudgetItem('income', item.id, 'amount', e.target.value)}
                      className="w-32 px-3 py-2 border-2 border-green-200 rounded-lg"
                      placeholder="Amount"
                    />
                    <select
                      value={item.frequency}
                      onChange={(e) => updateBudgetItem('income', item.id, 'frequency', e.target.value)}
                      className="px-3 py-2 border-2 border-green-200 rounded-lg"
                    >
                      <option value="Weekly">Weekly</option>
                      <option value="Bi-weekly">Bi-weekly</option>
                      <option value="Monthly">Monthly</option>
                      <option value="Yearly">Yearly</option>
                    </select>
                    <button
                      onClick={() => deleteBudgetItem('income', item.id)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Expenses Section */}
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-bold text-red-600">Expenses</h3>
                <button
                  onClick={() => addBudgetItem('expenses')}
                  className="flex items-center gap-2 px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200"
                >
                  <Plus className="w-4 h-4" />
                  Add Expense
                </button>
              </div>
              
              <div className="space-y-3">
                {data.budget.expenses.map(item => (
                  <div key={item.id} className="flex items-center gap-4 p-4 bg-red-50 rounded-lg">
                    <input
                      type="text"
                      value={item.name}
                      onChange={(e) => updateBudgetItem('expenses', item.id, 'name', e.target.value)}
                      className="flex-1 px-3 py-2 border-2 border-red-200 rounded-lg"
                      placeholder="Expense name"
                    />
                    <select
                      value={item.category}
                      onChange={(e) => updateBudgetItem('expenses', item.id, 'category', e.target.value)}
                      className="px-3 py-2 border-2 border-red-200 rounded-lg"
                    >
                      <option value="Housing">Housing</option>
                      <option value="Transportation">Transportation</option>
                      <option value="Food">Food</option>
                      <option value="Utilities">Utilities</option>
                      <option value="Healthcare">Healthcare</option>
                      <option value="Entertainment">Entertainment</option>
                      <option value="Shopping">Shopping</option>
                      <option value="Education">Education</option>
                      <option value="Other">Other</option>
                    </select>
                    <input
                      type="number"
                      value={item.amount}
                      onChange={(e) => updateBudgetItem('expenses', item.id, 'amount', e.target.value)}
                      className="w-32 px-3 py-2 border-2 border-red-200 rounded-lg"
                      placeholder="Amount"
                    />
                    <select
                      value={item.frequency}
                      onChange={(e) => updateBudgetItem('expenses', item.id, 'frequency', e.target.value)}
                      className="px-3 py-2 border-2 border-red-200 rounded-lg"
                    >
                      <option value="Daily">Daily</option>
                      <option value="Weekly">Weekly</option>
                      <option value="Monthly">Monthly</option>
                      <option value="Yearly">Yearly</option>
                    </select>
                    <button
                      onClick={() => deleteBudgetItem('expenses', item.id)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Savings Goals */}
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-bold text-blue-600">Savings Goals</h3>
                <button
                  onClick={() => addBudgetItem('savings')}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200"
                >
                  <Plus className="w-4 h-4" />
                  Add Goal
                </button>
              </div>
              
              <div className="space-y-3">
                {data.budget.savings.map(item => (
                  <div key={item.id} className="flex items-center gap-4 p-4 bg-blue-50 rounded-lg">
                    <input
                      type="text"
                      value={item.name}
                      onChange={(e) => updateBudgetItem('savings', item.id, 'name', e.target.value)}
                      className="flex-1 px-3 py-2 border-2 border-blue-200 rounded-lg"
                      placeholder="Savings goal"
                    />
                    <input
                      type="number"
                      value={item.amount}
                      onChange={(e) => updateBudgetItem('savings', item.id, 'amount', e.target.value)}
                      className="w-32 px-3 py-2 border-2 border-blue-200 rounded-lg"
                      placeholder="Target"
                    />
                    <input
                      type="date"
                      value={item.date}
                      onChange={(e) => updateBudgetItem('savings', item.id, 'date', e.target.value)}
                      className="px-3 py-2 border-2 border-blue-200 rounded-lg"
                    />
                    <button
                      onClick={() => deleteBudgetItem('savings', item.id)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Goals Tab */}
        {activeTab === 'goals' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-3xl font-bold text-gray-800">Life Goals</h2>
              <button
                onClick={addGoal}
                className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:shadow-lg transition-all"
              >
                <Plus className="w-5 h-5" />
                Add Goal
              </button>
            </div>

            {data.goals.items.length === 0 && (
              <div className="bg-white rounded-2xl shadow-xl p-12 text-center">
                <Calendar className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                <p className="text-gray-600 text-lg">No goals yet. Set your first goal!</p>
              </div>
            )}

            <div className="grid gap-6">
              {data.goals.items.map(goal => (
                <div key={goal.id} className="bg-white rounded-2xl shadow-xl p-8">
                  <div className="flex justify-between items-start mb-4">
                    <input
                      type="text"
                      value={goal.title}
                      onChange={(e) => updateGoal(goal.id, 'title', e.target.value)}
                      className="text-2xl font-bold border-b-2 border-transparent hover:border-blue-200 focus:border-blue-500 outline-none flex-1"
                    />
                    <button
                      onClick={() => deleteGoal(goal.id)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg ml-4"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                  
                  <textarea
                    value={goal.description}
                    onChange={(e) => updateGoal(goal.id, 'description', e.target.value)}
                    placeholder="Describe your goal..."
                    className="w-full h-24 p-4 border-2 border-gray-200 rounded-lg focus:border-blue-500 outline-none resize-none mb-4"
                  />
                  
                  <div className="flex items-center gap-4 mb-4">
                    <div>
                      <label className="text-sm text-gray-600 block mb-1">Deadline:</label>
                      <input
                        type="date"
                        value={goal.deadline}
                        onChange={(e) => updateGoal(goal.id, 'deadline', e.target.value)}
                        className="px-3 py-2 border-2 border-gray-200 rounded-lg"
                      />
                    </div>
                    
                    <div>
                      <label className="text-sm text-gray-600 block mb-1">Category:</label>
                      <select
                        value={goal.category}
                        onChange={(e) => updateGoal(goal.id, 'category', e.target.value)}
                        className="px-3 py-2 border-2 border-gray-200 rounded-lg"
                      >
                        <option value="Personal">Personal</option>
                        <option value="Career">Career</option>
                        <option value="Health">Health</option>
                        <option value="Finance">Finance</option>
                        <option value="Education">Education</option>
                        <option value="Relationships">Relationships</option>
                      </select>
                    </div>
                  </div>
                  
                  <div>
                    <label className="text-sm text-gray-600 block mb-2">Progress: {goal.progress}%</label>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={goal.progress}
                      onChange={(e) => updateGoal(goal.id, 'progress', parseInt(e.target.value))}
                      className="w-full accent-blue-600"
                    />
                    <div className="mt-2 bg-gray-200 rounded-full h-3 overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-blue-600 to-purple-600 h-full transition-all"
                        style={{ width: `${goal.progress}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Gallery Tab */}
        {activeTab === 'gallery' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-3xl font-bold text-gray-800">Photo Gallery</h2>
              <button
                onClick={handlePhotoUpload}
                className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:shadow-lg transition-all"
              >
                <Camera className="w-5 h-5" />
                Upload Photos
              </button>
            </div>

            {data.gallery.photos.length === 0 && (
              <div className="bg-white rounded-2xl shadow-xl p-12 text-center">
                <Camera className="w-16 h-16 mx-auto text-gray-300 mb-4" />
                <p className="text-gray-600 text-lg">No photos yet. Start building your memories!</p>
              </div>
            )}

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {data.gallery.photos.map(photo => (
                <div key={photo.id} className="bg-white rounded-2xl shadow-xl overflow-hidden">
                  <img src={photo.src} alt={photo.caption} className="w-full h-64 object-cover" />
                  <div className="p-4">
                    <input
                      type="text"
                      value={photo.caption}
                      onChange={(e) => updatePhotoCaption(photo.id, e.target.value)}
                      placeholder="Add a caption..."
                      className="w-full px-3 py-2 border-2 border-gray-200 rounded-lg focus:border-blue-500 outline-none mb-2"
                    />
                    <div className="flex justify-between items-center">
                      <p className="text-sm text-gray-500">{photo.date}</p>
                      <button
                        onClick={() => deletePhoto(photo.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}