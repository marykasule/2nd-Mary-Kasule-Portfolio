import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import CareerJourney from './CareerJourney';
import LifeJournal from './LifeJournal';
import { Briefcase, BookOpen } from 'lucide-react';

function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-100 via-purple-100 to-pink-100 flex items-center justify-center p-8">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-12">
          <h1 className="text-6xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-4">
            Welcome to My Space
          </h1>
          <p className="text-xl text-gray-700">Choose where you'd like to go</p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          <Link to="/career" className="group">
            <div className="bg-white rounded-3xl shadow-2xl p-8 hover:scale-105 transition-all duration-300 cursor-pointer">
              <div className="w-20 h-20 bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Briefcase className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-3xl font-bold text-gray-800 mb-3">Career Journey</h2>
              <p className="text-gray-600 text-lg">
                Explore my professional transformation from massage therapy to healthcare data analytics
              </p>
              <div className="mt-6 text-purple-600 font-semibold flex items-center gap-2">
                Enter →
              </div>
            </div>
          </Link>
          
          <Link to="/journal" className="group">
            <div className="bg-white rounded-3xl shadow-2xl p-8 hover:scale-105 transition-all duration-300 cursor-pointer">
              <div className="w-20 h-20 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <BookOpen className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-3xl font-bold text-gray-800 mb-3">Life Journal</h2>
              <p className="text-gray-600 text-lg">
                Organize my thoughts, goals, finances, and daily life in one beautiful space
              </p>
              <div className="mt-6 text-blue-600 font-semibold flex items-center gap-2">
                Enter →
              </div>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
}

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/career" element={<CareerJourney />} />
        <Route path="/journal" element={<LifeJournal />} />
      </Routes>
    </Router>
  );
}

export default App;
