# 🌟 My Career & Life Journey Websites

A beautiful, interactive dual-website application showcasing my career transformation and personal life management.

![React](https://img.shields.io/badge/React-18-blue)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-3.0-38B2AC)
![License](https://img.shields.io/badge/License-MIT-green)

## 🎯 Live Demo

Visit the live websites:
- **Home**: [Link to your GitHub Pages URL]
- **Career Journey**: [Link]/career
- **Life Journal**: [Link]/journal

## 📖 About

This project consists of two interconnected React applications:

### 1. Career Journey 
A professional portfolio showcasing my transition from massage therapy to healthcare data analytics, featuring:
- Interactive career timeline
- Skills tracker (technical & healthcare domain expertise)
- Portfolio projects
- Career goals and target roles
- Image upload capabilities

### 2. Life Journal & Planner
A comprehensive personal organization tool with:
- Daily journal with mood tracking
- Task and reminder management
- Budget tracker (income, expenses, savings goals)
- Life goals with progress tracking
- Photo gallery with captions

## 🛠️ Technologies Used

- **React** - Frontend framework
- **React Router** - Navigation
- **Tailwind CSS** - Styling
- **Lucide React** - Icons
- **LocalStorage** - Data persistence

## 🚀 Features

- ✨ Beautiful gradient designs
- 📱 Fully responsive (mobile, tablet, desktop)
- 💾 Automatic data saving
- 🎨 Easy customization
- 📸 Image upload support
- ✏️ Inline editing
- 🎯 Intuitive navigation

## 💻 Running Locally

1. Clone this repository:
```bash
git clone https://github.com/YOUR-USERNAME/my-websites.git
cd my-websites
```

2. Install dependencies:
```bash
npm install
```

3. Start development server:
```bash
npm start
```

4. Open http://localhost:3000 in your browser

## 🏗️ Building for Production

```bash
npm run build
```

This creates an optimized production build in the `build` folder.

## 📂 Project Structure

```
my-websites/
├── public/
│   └── index.html
├── src/
│   ├── App.js              # Main app with routing
│   ├── CareerJourney.js    # Career website component
│   ├── LifeJournal.js      # Journal/planner component
│   ├── index.js            # Entry point
│   └── index.css           # Global styles
├── build/                   # Production build (generated)
└── package.json            # Dependencies
```

## 🎨 Customization

### Changing Colors
Edit the gradient classes in the component files:
- `from-purple-600 to-pink-600` - Career Journey theme
- `from-blue-600 to-indigo-600` - Life Journal theme

### Adding Features
The code is well-organized and commented. Each component is self-contained and easy to modify.

### Data Storage
Currently uses browser LocalStorage. To sync across devices, consider:
- Firebase Realtime Database
- Supabase
- Your own backend API

## 📝 Future Enhancements

- [ ] Cloud data sync
- [ ] Export/import functionality
- [ ] Dark mode
- [ ] Calendar integration
- [ ] Data visualization charts
- [ ] Mobile app version
- [ ] Password protection
- [ ] Share journal entries

## 🤝 Contributing

This is a personal project, but suggestions are welcome! Feel free to:
1. Fork the repository
2. Create a feature branch
3. Submit a pull request

## 📄 License

MIT License - feel free to use this code for your own projects!

## 👤 About Me

**Mary** - Healthcare professional transitioning to Data Analytics

- 🎓 Completing Google Data Analytics Certificate via Merit America
- 💼 Background: Massage Therapy, Cardiac Rehabilitation
- 🎯 Goal: Epic Credentialed Trainer / Healthcare Data Analyst
- 📍 Location: Herndon, Virginia
- 🔧 Learning: R, SQL, Tableau, Python

## 📧 Contact

[Your Email] | [LinkedIn] | [GitHub]

---

⭐ If you find this project helpful, please consider giving it a star!

**Built with ❤️ and React**
